function [b]= Saturation(a,width)
b = a;
b(find(a>(2^(width-1)-1))) = 2^(width-1)-1;
b(find(a<(1-2^(width-1)))) = -2^(width-1);
%len = length(a);
%for i = 1:len
%	if(a(i)>(2^(width-1)-1))
%		b(i) = 2^(width-1)-1;
%	elseif(a(i)<(1-2^(width-1)))
%		b(i) = 1-2^(width-1);
%	else
%		b(i) = a(i);
%    end
%end