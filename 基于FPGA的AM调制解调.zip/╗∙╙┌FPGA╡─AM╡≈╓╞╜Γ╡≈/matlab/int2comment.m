function [dataout] = int2comment(datain,width)
dataout = datain;
a = find(datain<0);%�ҵ���0С��Ԫ��
dataout(a) = dataout(a) + 2^(width);
%len = length(a);
%for ii = 1 : len
%	if(a(ii) < 0)
%		b(ii) = 2^(width-1) + a(ii);
%	else
%		b(ii) = a(ii);
%	end
%end