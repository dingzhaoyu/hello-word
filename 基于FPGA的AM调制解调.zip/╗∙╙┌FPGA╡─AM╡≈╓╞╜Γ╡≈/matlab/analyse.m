clc;
clear all;
close all;
%%���
fid = textread('data_out\sqrt_data.txt','%s');

data = hex2dec(fid);
N = length(data);
for i=1:N
    if(data(i) > 32768)
        data(i)=data(i)-65536;
    end
end
for i=1:N
  data_point(i) =  data(i)./32768;
end
figure(1);
subplot(4,1,1),
k=data_point;
plot(data_point);grid on;title('����ź�');
%%
%%�����ź�
fid = textread('data_out\i_mat_data_i.txt','%s');
data = hex2dec(fid);

N = length(data);
for i=1:N
    if(data(i) > 32768)
        data(i)=data(i)-65536;
    end
end
for i=1:N
  data_point(i) =  data(i)./32768;
end
subplot(4,1,2),
k=data_point;
plot(data_point);grid on;title('�����ź�');
%%
%%�ѵ��ź�
fid = textread('data_out\am_mod_data_r.txt','%s');
data = hex2dec(fid);

N = length(data);
for i=1:N
    if(data(i) > 32768)
        data(i)=data(i)-65536;
    end
end
for i=1:N
  data_point(i) =  data(i)./32768;
end
subplot(4,1,3),
plot(data_point);grid on;title('�ѵ����ź�');
%%
%%�±�Ƶ
fid = textread('data_out\o_ddc_i_r.txt','%s');
data = hex2dec(fid);

N = length(data);
for i=1:N
    if(data(i) > 32768)
        data(i)=data(i)-65536;
    end
end
for i=1:N
  data_point(i) =  data(i)./32768;
end
subplot(4,1,4),
plot(data_point);grid on;title('�±�Ƶ�ź�');
%%
%%���˲���
fid = textread('data_out\o_fir_data_i_r.txt','%s');
data = hex2dec(fid);

N = length(data);
for i=1:N
    if(data(i) > 32768)
        data(i)=data(i)-65536;
    end
end
for i=1:N
  data_point(i) =  data(i)./32768;
end
figure(2);
subplot(4,1,1),
plot(data_point);grid on;title('���˲����ź�');
%%
%%ƽ��
fid = textread('data_out\o_square_i2_r.txt','%s');
data = hex2dec(fid);

N = length(data);
% for i=1:N
%     if(data(i) > 32768*32768)
%         data(i)=data(i)-2*32768*32768;
%     end
% end
for i=1:N
  data_point(i) =  data(i)./(32768*32768);
end
subplot(4,1,2),
plot(data_point);grid on;title('ƽ���ź�');
%%
%%ƽ�����
fid = textread('data_out\o_data_iq2_r.txt','%s');
data = hex2dec(fid);

N = length(data);
% for i=1:N
%     if(data(i) > 32768)
%         data(i)=data(i)-65536;
%     end
% end
for i=1:N
  data_point(i) =  data(i)./(32768*32768*2);
end
subplot(4,1,3),
plot(data_point);grid on;title('ƽ������ź�');
%%
%%����
fid = textread('data_out\o_sqrt_datar_r.txt','%s');
data = hex2dec(fid);

N = length(data);
for i=1:N
    if(data(i) > 32768)
        data(i)=data(i)-65536;
    end
end
for i=1:N
  data_point(i) =  data(i)./32768;
end

subplot(4,1,4),
plot(data_point);grid on;title('�����ź�');
figure(4);
plot(k);
hold on;
plot(data_point,'r');title('��������źűȽ�');
[max1 k] = max(k(2000:4000))
[max2 data_point] = max(data_point(2000:4000))













