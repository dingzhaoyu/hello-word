clc;
clear all;
close all;
fid = textread('sim_data\i_fir_data_i.txt','%s');
data = hex2dec(fid);
% fidd = textread('.\table\madata.dat','%s');
% dataa = hex2dec(fidd);

N = length(data);
for i=1:N
    if(data(i) > 32768)
        data(i)=data(i)-65536;
    end
end
for i=1:N
  data_point(i) =  data(i)./32768;
end
%%
fid1 = textread('sim_data\o_fir_data_i.txt','%s');
data_o = hex2dec(fid1);
% fidd = textread('.\table\madata.dat','%s');
% dataa = hex2dec(fidd);

N1 = length(data_o);
for i1=1:N1
    if(data_o(i1) > 32768)
        data_o(i1)=data_o(i1)-65536;
    end
end
for i1=1:N1
  data_point_o(i1) =  data_o(i1)./32768;
end
figure(2);
plot(data_point);
hold on;
plot(data_point_o,'r');title('��������źűȽ�');
[max1 data_point] = max(k(2000:4000))
[max2 data_point_o] = max(data_point(2000:4000))